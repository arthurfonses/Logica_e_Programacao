﻿namespace ExercicioDeDecisão
{
    partial class Frmexemplo2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.projetoCoelhoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.batataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alfaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cenouaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.projetoCoelhoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // projetoCoelhoToolStripMenuItem
            // 
            this.projetoCoelhoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.batataToolStripMenuItem,
            this.alfaceToolStripMenuItem,
            this.cenouaToolStripMenuItem});
            this.projetoCoelhoToolStripMenuItem.Name = "projetoCoelhoToolStripMenuItem";
            this.projetoCoelhoToolStripMenuItem.Size = new System.Drawing.Size(96, 20);
            this.projetoCoelhoToolStripMenuItem.Text = "Projeto coelho";
            // 
            // batataToolStripMenuItem
            // 
            this.batataToolStripMenuItem.Name = "batataToolStripMenuItem";
            this.batataToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.batataToolStripMenuItem.Text = "batata";
            // 
            // alfaceToolStripMenuItem
            // 
            this.alfaceToolStripMenuItem.Name = "alfaceToolStripMenuItem";
            this.alfaceToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.alfaceToolStripMenuItem.Text = "alface";
            // 
            // cenouaToolStripMenuItem
            // 
            this.cenouaToolStripMenuItem.Name = "cenouaToolStripMenuItem";
            this.cenouaToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.cenouaToolStripMenuItem.Text = "cenoua";
            // 
            // Frmexemplo2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Frmexemplo2";
            this.Text = "Exercicio de descisão";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem projetoCoelhoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem batataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alfaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cenouaToolStripMenuItem;
    }
}